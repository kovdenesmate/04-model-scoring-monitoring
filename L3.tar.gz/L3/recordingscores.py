import ast
import pandas as pd
import numpy as np

recent_r2=0.6
recent_sse=52938


#record a score in a DataFrame


#find the maximum version number


#generate rows


#write the dataset to a csv


