import ast
import numpy as np

newr2=0.3625


