f = open("/home/workspace/L2/demo1/crondemo.txt", "a")
f.write("Your cron job worked - great job!")
f.close()